﻿using System;

namespace OOPS_MultipleInheritance_thru_interfaces
{
    interface IRental_Company        //Interface
    {
        /*int id { get; set; }
        int number_days_of_rental { get; set; }
        float price { get; set; }*/
        void print_info(int id, int number_days_of_rental, int price);
    
    }
    interface Icar                    //Interface
    {
         void print_number_doors(int number_of_doors);
        
    }
    interface Itrucks                  //Interface
    {
        void speed(int speed_km);
        
    }
    class calculate : IRental_Company, Icar, Itrucks  // Multiple Inheritance thru  three interfaces
    {
        /*int id;
        public int number_days_of_rental;
        public float price;
        public int speed_km;
        public int number_of_doors;*/
        public void print_info(int id,int number_days_of_rental,int price)
        {
            Console.WriteLine("The rental id is :" + id);
            Console.WriteLine("The number of days of booking :" + number_days_of_rental);
            Console.WriteLine("The booking price is :" + price);
        }
        public void print_number_doors(int number_of_doors)
        {
            Console.WriteLine("The number of doors is :" + number_of_doors);
        }
        public void speed(int speed_km)
        {
            Console.WriteLine("The speed is :" + speed_km);
        }

    }
    class Program           // Exhibiting Multiple Inheritance using interface 
    {
        static void Main(string[] args)
        {
            //Instantiating calculate class
            calculate myrental = new calculate();
            // Car class can access all properties and methods of base class Rental_Company
           /* myrental.id = 5634233;
            myrental.number_days_of_rental = 30;
            myrental.price = 900;*/
            myrental.print_info(5644,30,900);

            // Car class properties and methods
           // myrental.number_of_doors = 4;
            myrental.print_number_doors(4);


            //Instantiating trucks class
           
            // trucks class can access all properties and methods of base class Rental_Company
           

            //trucks class properties and methods
           // myrental.speed_km = 100;
            myrental.speed(100);

            Console.ReadKey();


        }
    }
}
