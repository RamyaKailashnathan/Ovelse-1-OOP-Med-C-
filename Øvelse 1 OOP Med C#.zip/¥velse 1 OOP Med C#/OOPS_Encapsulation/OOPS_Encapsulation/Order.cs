﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OOPS_Encapsulation
{
    class Order
    {
        public string orderNo;
        public string orderValue;
        public string orderCountry;

        public void Create_Validate(string orderNo, string orderValue, string orderCountry)
        {

            Console.WriteLine("Order Created:  {0}, {1} , {2} ", orderNo, orderValue, orderCountry);
            Console.WriteLine("Encapsulating two methods.");
     
            if (ValidateOrderCountry(orderCountry)) // encapsulating country validation  
            {
                Console.WriteLine(" Order country has been validated");
            }
            else
            {
                Console.WriteLine(" Order country has not been validated");
            }
            if (ValidateOrderValue(orderValue)) // encapsulating order value validation
            {
                Console.WriteLine(" Order value has been validated");
            }
            else
            {
                Console.WriteLine(" Order value has not been validated");
            }
        }
        private bool ValidateOrderValue(string orderValue)
        {
         
            bool result = orderValue.Equals("5000");
            return result;
        }
        private bool ValidateOrderCountry(string orderCountry)
        {
            bool result = orderCountry.Equals("Danmark");
            return result;
        }
    }
}
