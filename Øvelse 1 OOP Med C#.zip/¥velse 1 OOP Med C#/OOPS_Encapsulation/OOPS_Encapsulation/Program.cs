﻿using System;

namespace OOPS_Encapsulation
{
    class Program
    {
        static void Main(string[] args)
        {
            Order order = new Order();

            Console.Write("Enter the order number:");
            string n = Console.ReadLine();
            Console.Write("Enter the order value:");
            string v = Console.ReadLine(); 
            Console.Write("Enter the order country:");
            string c = Console.ReadLine();
            order.Create_Validate(n,v,c);

            
        }
    }
}

