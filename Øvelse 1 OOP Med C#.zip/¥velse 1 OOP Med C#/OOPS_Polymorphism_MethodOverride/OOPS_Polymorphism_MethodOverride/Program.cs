﻿using System;

namespace OOPS_Polymorphism_MethodOverride
{
    class Program  // USING VIRTUAL AND OVERRIDE KEYWORD
    {
        public class Parent
        {
            
            public virtual void print()
            {
                Console.WriteLine("Print from Parent class");
            }
        }
        public class Child : Parent
        {
         
            public override void print()
            {
                Console.WriteLine("Print from Child class");
            }
        }
        static void Main(string[] args)
        {
            Parent pp = new Parent();
            pp.print();

            // the same object 'pp' is now
            // the object of class 'Child'
            pp = new Child();
            // it invokes 'print()' of class 'Childd'
            // 'print()' of class 'Child' is overridden
            // for 'override' modifier
            pp.print();

        }
    }
}
