﻿using System;

namespace OOPS_Polymorphism_MethodOverloading
{
    class Program
    {
        class Poly_Method_Overload
        {
            public int add()                                          // Blank parameters
            {
                return 2 + 3;
            }
            public int add(int a, int b)                             // Adding two parameters(integers)
            {
                return a + b;
            }
            public float add(float a,float b, float c)       // Adding three parameters(float)
            {
                return a + b + c;
            }
            public float add(float a, float b, float c,int d)       // Adding four parameters(different datatypes)
            {
                return a + b + c + d;
            }
            public float add(int a, float b, float c, float d)       // Adding four parameters(different sequence)
            {
                return a + b + c + d;
            }


        }
        static void Main(string[] args)
        {
            Poly_Method_Overload po = new Poly_Method_Overload();
            po.add();                                           // Blank parameters
            po.add(67, 34);                                     // Adding two parameters(integers)
            po.add(10.5f,13.5f,16.5f);                          // Adding three parameters(float)
            po.add(14.5f, 17.5f, 19.5f, 90);                    // Adding four parameters(different datatypes)
            po.add(100, 45.5f, 34.5f, 16.9f);                   // Adding four parameters(different sequence)

        }
    }
}
