﻿using System;

namespace OOPS_Abstraction1
{
        public abstract class Car   // Abstract Class
        {
        #region Public Methods,Regular Methods

            public void Drive()
            {
                Console.WriteLine("Driving a car-Calling base class method");
            }
            public void RadioOn()
            {
                Console.WriteLine("RadioOn in a car-Calling base class method");
            }
            public void Handbrakeoff()
            {
                Console.WriteLine("Handbrakeoff in a car-Calling base class method");
            }
        #endregion
        #region Abstract methods
            public abstract void CalculateSpeed();// Abstract Method(does not have a body)
   
            public abstract void WindWindowsDown();// Abstract Method

            public abstract void MoveSeatForward();// Abstract Method
        #endregion
        }
        public class BudgetCar : Car    //Derived class,inherit fra Car class
        {
            public override void CalculateSpeed() // Actual implementation eller logic til Budget car
            {
                Console.WriteLine("Budget Car Speed Calculation");
                Console.Write("Enter the distance:  ");
                double dist = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter the time:  ");
                double time = Convert.ToDouble(Console.ReadLine());
                double speed = dist / time;
                Console.Write("The speed calculation for Budget car : {0}", speed);
            }
            public override void MoveSeatForward()
            {
                Console.WriteLine("Moved Seat Forward for Budget car");
            }
            public override void WindWindowsDown()
            {
                Console.WriteLine("Put the windows down for Budget car");
            }
        }

        public class SportsCar : Car //Derived class,inherit fra Car class
        {
            public override void CalculateSpeed() // Actual implementation eller logic til Sports car
            {
                 Console.WriteLine("Sports Car Speed Calculation");
                 Console.Write("Enter the distance:  ");
                 double dist = Convert.ToDouble(Console.ReadLine());
                 Console.Write("Enter the time:  ");
                 double time = Convert.ToDouble(Console.ReadLine());
                 double speed = dist / time;
                 Console.Write("The speed calculation for Sports Car: {0}", speed);

            }

        public override void MoveSeatForward()
            {
                Console.WriteLine("Moved Seat Forward for Sports car");
            }

             public override void WindWindowsDown()
            {
                 Console.WriteLine("Put the windows down for Sports car");
            }
        }
    class Program
    {
        private static void DoStuffToCar(Car car)
        {
            Console.WriteLine("Base class call---");
            car.Drive();
            car.RadioOn();
            car.Handbrakeoff();
            Console.WriteLine();
            Console.WriteLine("Abstract class call---");
            car.CalculateSpeed();
            Console.WriteLine();
            car.MoveSeatForward();
            car.WindWindowsDown();
        }
        static void Main(string[] args)
        {
            var bc = new BudgetCar();
            Console.WriteLine("BUDGET CAR");
            DoStuffToCar(bc);
            Console.ReadLine();
            Console.Clear();

            var sc = new SportsCar();
            Console.WriteLine("SPORTS CAR");
            DoStuffToCar(sc);
            Console.ReadLine();
        }
       
            
       
    }
}
