﻿using System;

namespace OOPS_Inheritance_Types
{
    class Rental_Company        //Base class
    {
        public int id;
        public int number_days_of_rental;
        public float price;

        public void print_info()
        {
            Console.WriteLine("The rental id is :" + id);
            Console.WriteLine("The number of days of booking :" + number_days_of_rental);
            Console.WriteLine("The booking price is :" + price);
        }
    }
    class car:Rental_Company   //Inheriting from Base class(Rental_Company)
    {
        public int number_of_doors;
        public void print_number_doors()
        {
            Console.WriteLine("The number of doors is :"+number_of_doors);
        }
    }
    class trucks :Rental_Company //Inheriting from Base class(Rental_Company)
    {
        public int speed_km;
        public void speed()
        {
            Console.WriteLine("The speed is :" + speed_km);
        }
    }
    class Program           // Exhibiting Hierachial Inheritance 
    {
        static void Main(string[] args)
        {
            //Instantiating Car class
            car myrental = new car();
            // Car class can access all properties and methods of base class Rental_Company
            myrental.id = 5634233;
            myrental.number_days_of_rental = 30;
            myrental.price = 900;
            myrental.print_info();

            // Car class properties and methods
            myrental.number_of_doors = 4;
            myrental.print_number_doors();
           

            //Instantiating trucks class
            trucks myrental1 = new trucks();
            // trucks class can access all properties and methods of base class Rental_Company
            myrental1.id = 5634233;
            myrental1.number_days_of_rental = 30;
            myrental1.price = 900;
            myrental1.print_info();

            //trucks class properties and methods
            myrental1.speed_km=100;
            myrental1.speed();

            Console.ReadKey();
            

        }
    }
}
